# -*- coding: utf-8 -*-
"""
Created on Sun Feb 23 08:54:40 2020

"""


import pickle
import numpy as np
p = pickle.load(open('waf/trained_waf_model', 'rb'))

# type inthe console
vars(p)
vec = p.steps[0][1]
vec

clf = p.steps[1][1]
clf


print(vec.idf_)

print(clf.coef_)

term_influence = vec.idf_ * clf.coef_
print(term_influence)


print(np.argpartition(term_influence, 1))


vec.vocabulary_

# First, we create a token vocabulary dictionary so that
# we can access tokens by index.
vocab = dict([(v,k) for k,v in vec.vocabulary_.items()])

term_idx = np.argpartition(term_influence, 1)[0][0]

print(vocab[term_idx])


payload = "<script>alert(1)</script>"


p.predict([payload])[0]


p.predict_proba([payload])[0]


p.predict_proba([payload + '/' + vocab[term_idx]])[0]


p.predict_proba([payload + '/' + vocab[term_idx]*258])[0]


p.predict([payload + '/' + vocab[term_idx]*258])[0]


print(payload + '/' + vocab[term_idx]*258)



