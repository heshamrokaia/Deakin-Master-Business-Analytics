"""
Module providing poisoning attacks under a common interface.
"""
from art.attacks.poisoning.poisoning_attack_svm import PoisoningAttackSVM
